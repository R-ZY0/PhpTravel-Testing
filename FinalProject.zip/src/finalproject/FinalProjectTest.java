package finalproject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class FinalProjectTest {
    public static void main(String[] args) {
        // Setup ChromeDriver path
        System.setProperty("webdriver.chrome.driver", "C:\\chromedriver\\chromedriver.exe");

        WebDriver driver = new ChromeDriver();
        WebDriverWait wait = new WebDriverWait(driver, 10);

        try {
            // Open the website
            driver.manage().window().maximize();
            driver.get("https://www.phptravels.net/login");

            // Login as Admin
            driver.findElement(By.name("email")).sendKeys("admin@phptravels.com");
            driver.findElement(By.name("password")).sendKeys("demoadmin");
            driver.findElement(By.xpath("//button[@type='submit']")).click();

            Thread.sleep(3000);

            // Test different reports
            testReport(driver, wait, "Weekly Bookings");
            testReport(driver, wait, "Monthly Bookings");
            testReport(driver, wait, "Annually Bookings");
            testReport(driver, wait, "Weekly Users");
            testReport(driver, wait, "Monthly Users");
            testReport(driver, wait, "Annually Users");
            testReport(driver, wait, "Payment Transactions");
            testReport(driver, wait, "Annual Income Report");

        } catch (Exception e) {
            System.out.println("Test failed: " + e.getMessage());
        } finally {
            driver.quit();
        }
    }

    public static void testReport(WebDriver driver, WebDriverWait wait, String reportName) {
        try {
            // Click on Reports
            WebElement reportsLink = wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Reports")));
            reportsLink.click();

            // Click on specific report
            WebElement reportLink = wait.until(ExpectedConditions.elementToBeClickable(By.linkText(reportName)));
            reportLink.click();

            // Wait until data table appears
            WebElement table = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("data")));

            if (table.isDisplayed()) {
                System.out.println(reportName + ": PASS - Report displayed successfully.");
            } else {
                System.out.println(reportName + ": FAIL - Report data not visible.");
            }
        } catch (Exception e) {
            System.out.println(reportName + ": FAIL - Exception occurred: " + e.getMessage());
        }
    }
}