package data;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class LoadLoginProperties {
	static public String filePath = System.getProperty("user.dir")+"\\src\\main\\java\\Properties\\LoginData.properties";
	
	static public Properties loginData = loadProperties(filePath);
	
	private static Properties loadProperties(String filePath) {
		System.out.println(filePath);
		
		Properties pro = new Properties();
		try {
			FileInputStream stream = new FileInputStream(filePath);
			try {
				pro.load(stream);
			} catch (IOException e) {
				System.out.println("Error Occupied "+e.getMessage());
			}
		} catch (FileNotFoundException e) {
			System.out.println("Error Occupied "+e.getMessage());
		}
		
		return pro;
	}
}
