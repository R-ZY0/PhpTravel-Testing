package tests;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import data.LoadLoginProperties;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.time.Duration;

import pages.LoginPage;

public class Login_happyScenario extends TestBase {
    LoginPage loginObject;
    String email = LoadLoginProperties.loginData.getProperty("email");
    String password = LoadLoginProperties.loginData.getProperty("password");

    @BeforeMethod
    public void initPageObjects() {
        loginObject = new LoginPage(driver); // ✅ Initialized after driver is ready
    }

    @Test(priority = 1)
    public void testLogin_CorrectUsernameAndPassword() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        wait.until(ExpectedConditions.visibilityOf(loginObject.loginMessage));
        Assert.assertEquals(loginObject.loginMessage.getText(), "Powered by PHPTRAVELS");

        loginObject.userCanLogin(email, password);

        wait.until(ExpectedConditions.visibilityOf(loginObject.successMassege));
        Assert.assertEquals(loginObject.successMassege.getText(), "Dashboard");
        loginObject.clickReportsBtn();
        wait.until(ExpectedConditions.visibilityOf(loginObject.listReport_First));
        Assert.assertEquals("Weekly Bookings", loginObject.listReport_First.getText());
        
        
        
        loginObject.listReport_F(); 
        boolean isValid = loginObject.isCanvasValid();
        Assert.assertTrue(isValid, "Report canvas is not valid (height is less than required or incorrect width).");
        loginObject.listReport_S(); 
        boolean w = loginObject.isCanvasValid();
        Assert.assertTrue(w, "Report canvas is not valid (height is less than required or incorrect width).");
        loginObject.listReport_T(); 
        boolean s = loginObject.isCanvasValid();
        Assert.assertTrue(s, "Report canvas is not valid (height is less than required or incorrect width).");
        loginObject.listReport_Four(); 
        boolean f = loginObject.isCanvasValid();
        Assert.assertFalse(f, "Report canvas is not valid (height is less than required or incorrect width).");
        loginObject.listReport_Fifth(); 
        boolean h = loginObject.isCanvasValid();
        Assert.assertFalse(h, "Report canvas is not valid (height is less than required or incorrect width).");
        loginObject.listReport_Sixth(); 
        boolean q = loginObject.isCanvasValid();
        Assert.assertFalse(q, "Report canvas is not valid (height is less than required or incorrect width).");
        loginObject.listReport_Seventh(); 
        boolean r = loginObject.isCanvasValid();
        Assert.assertTrue(r, "Report canvas is not valid (height is less than required or incorrect width).");
        loginObject.listReport_eighth(); 
        boolean e = loginObject.isCanvasValid();
        Assert.assertTrue(e, "Report canvas is not valid (height is less than required or incorrect width).");
        
        
    
    
    }
    
}
