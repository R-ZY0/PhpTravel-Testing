package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import data.DataTest;

import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.time.Duration;


import pages.CarsBooking;
import pages.Cars_search_happey;
import pages.Cars_searh_nigative;


public class CarsTest_Nigative extends TestBase {
	String FromAirportError = DataTest.DataTests.getProperty("FromAirportError");
	String ToLocation = DataTest.DataTests.getProperty("ToLocation");
	String PickUpDate = DataTest.DataTests.getProperty("PickUpDate");
	String DropOffDate = DataTest.DataTests.getProperty("DropOffDate");
	int PickUpTime = Integer.parseInt(DataTest.DataTests.getProperty("PickUpTime"));
	int DropOffTime = Integer.parseInt(DataTest.DataTests.getProperty("DropOffTime"));
	int numAdults = Integer.parseInt(DataTest.DataTests.getProperty("numAdults"));
	int NumChilds = Integer.parseInt(DataTest.DataTests.getProperty("NumChilds"));

    Cars_search_happey CarsObject;
    Cars_searh_nigative CarsObjectn;
    CarsBooking BookingObject;

    @Test(priority = 1)
    public void CarsTest_nigative() throws InterruptedException {
        // ✅ Initialize the page objects after driver is initialized
        CarsObject = new Cars_search_happey(driver);
        CarsObjectn = new Cars_searh_nigative(driver);
        BookingObject = new CarsBooking(driver);

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        // Click Cars
        CarsObject.clickToCars();
        wait.until(ExpectedConditions.visibilityOf(CarsObject.InCarsMassege));
        Assert.assertEquals("Select City", CarsObject.InCarsMassege.getText());

        // From Location
        CarsObject.dropFrom();
        wait.until(ExpectedConditions.visibilityOf(CarsObject.inputFrom_To));
        CarsObject.FromAirport(FromAirportError);

        // To Location
        CarsObject.dropTo();
        wait.until(ExpectedConditions.visibilityOf(CarsObject.inputFrom_To));
        CarsObject.ToLocation(ToLocation);

        // Fill dates
        CarsObject.FillData(PickUpDate,PickUpTime,DropOffDate,DropOffTime);

        // Traveller info
        CarsObject.Tr();
        wait.until(ExpectedConditions.visibilityOf(CarsObject.resultAdults));
        CarsObject.TravellerDropdownIn(numAdults,NumChilds);
        Assert.assertEquals("2", CarsObject.TotalResult.getText());

        // Search
        wait.until(ExpectedConditions.elementToBeClickable(CarsObject.BtnSearchButton));
        CarsObject.BtnSearch();

        // Check for error card (No Data)
        CarsObjectn.noDataCard(driver);
        Assert.assertTrue(driver.findElement(By.cssSelector(".vt-card.error")).isDisplayed(), "Expected 'No More Data' alert to be visible.");
    }
}
