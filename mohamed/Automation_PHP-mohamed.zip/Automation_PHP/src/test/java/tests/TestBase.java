package tests;

import org.testng.annotations.Test;
import data.LoadDriverProperties;
import org.testng.annotations.BeforeTest;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;

public class TestBase {
    WebDriver driver;
    String baseURL;
    String browserName;

    @BeforeTest
    public void openBrowser() {
        baseURL = LoadDriverProperties.driverData.getProperty("baseURL");
        browserName = LoadDriverProperties.driverData.getProperty("browserName");

        
        if (browserName.equalsIgnoreCase("chrome"))
            driver = new ChromeDriver();
        else if (browserName.equalsIgnoreCase("firefox"))
            driver = new FirefoxDriver();
        else if (browserName.equalsIgnoreCase("edge"))
            driver = new EdgeDriver();
        else
            throw new RuntimeException("Unsupported browser: " + browserName);

        long timeout = Long.parseLong(LoadDriverProperties.driverData.getProperty("timeout"));
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(timeout));

        if (baseURL == null || !baseURL.startsWith("http")) {
            throw new RuntimeException("Invalid base URL: " + baseURL);
        }

        driver.navigate().to(baseURL);
    }

    @AfterTest
    public void closeBrowser() {
        if (driver != null)
            driver.quit();
    }
}
