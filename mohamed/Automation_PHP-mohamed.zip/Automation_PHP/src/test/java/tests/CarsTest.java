package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import data.DataTest;
import data.LoadLoginProperties;

import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.time.Duration;

import pages.CarsBooking;
import pages.Cars_search_happey;


public class CarsTest extends TestBase {
	String FromAirport = DataTest.DataTests.getProperty("FromAirport");
	String ToLocation = DataTest.DataTests.getProperty("ToLocation");
	String PickUpDate = DataTest.DataTests.getProperty("PickUpDate");
	String DropOffDate = DataTest.DataTests.getProperty("DropOffDate");
	String FirstName = DataTest.DataTests.getProperty("FirstName");
	String LastName = DataTest.DataTests.getProperty("LastName");
	String Email = DataTest.DataTests.getProperty("Email");
	String Phone = DataTest.DataTests.getProperty("Phone");
	String Address = DataTest.DataTests.getProperty("Address");
	String Nationality = DataTest.DataTests.getProperty("Nationality");
	String CurrentCode = DataTest.DataTests.getProperty("CurrentCode");
	String title = DataTest.DataTests.getProperty("title");
	String FirstN = DataTest.DataTests.getProperty("FirstN");
	String LastN = DataTest.DataTests.getProperty("LastN");
	String Age = DataTest.DataTests.getProperty("Age");
	String first = DataTest.DataTests.getProperty("first");
	String Last = DataTest.DataTests.getProperty("Last");
	int PickUpTime = Integer.parseInt(DataTest.DataTests.getProperty("PickUpTime"));
	int DropOffTime = Integer.parseInt(DataTest.DataTests.getProperty("DropOffTime"));
	int numAdults = Integer.parseInt(DataTest.DataTests.getProperty("numAdults"));
	int NumChilds = Integer.parseInt(DataTest.DataTests.getProperty("NumChilds"));
	int payment = Integer.parseInt(DataTest.DataTests.getProperty("payment"));

    
    
	Cars_search_happey CarsObject;
    CarsBooking BookingObject;
    

    @Test(priority = 1)
    public void CarsTest() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        CarsObject = new Cars_search_happey(driver);
        BookingObject = new CarsBooking(driver);

        // Click Cars
        CarsObject.clickToCars();
        wait.until(ExpectedConditions.visibilityOf(CarsObject.InCarsMassege));
        Assert.assertEquals("Select City", CarsObject.InCarsMassege.getText());

        // From Location
        CarsObject.dropFrom();
        wait.until(ExpectedConditions.visibilityOf(CarsObject.inputFrom_To));
        CarsObject.FromAirport(FromAirport);

        // To Location
        CarsObject.dropTo();
        wait.until(ExpectedConditions.visibilityOf(CarsObject.inputFrom_To));
        CarsObject.ToLocation(ToLocation);

        // Fill dates
        CarsObject.FillData(PickUpDate, PickUpTime, DropOffDate, DropOffTime);

        // Traveller info
        CarsObject.Tr();
        wait.until(ExpectedConditions.visibilityOf(CarsObject.resultAdults));
        CarsObject.TravellerDropdownIn(numAdults,NumChilds);

        Assert.assertEquals("2", CarsObject.TotalResult.getText());

        // Search
        wait.until(ExpectedConditions.elementToBeClickable(CarsObject.BtnSearchButton));
        CarsObject.BtnSearch();

        wait.until(ExpectedConditions.visibilityOf(CarsObject.SearchRe));
        Assert.assertEquals("Book Now", CarsObject.SearchRe.getText());
    }

    @Test(dependsOnMethods = {"CarsTest"})
    public void Booking() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        wait.until(ExpectedConditions.elementToBeClickable(BookingObject.getBtnBook(2)));
        BookingObject.BtnBook(2);

        wait.until(ExpectedConditions.visibilityOf(BookingObject.massegeInBooking));
        Assert.assertEquals("Cars Booking", BookingObject.massegeInBooking.getText());
       
        wait.until(ExpectedConditions.visibilityOf(BookingObject.getFirstNameField()));
        BookingObject.FillData(FirstName, LastName,Email, Phone, Address );
        
        BookingObject.nationality();
        wait.until(ExpectedConditions.visibilityOf(BookingObject.Nationali));
        BookingObject.matherNationality(Nationality);

        
        BookingObject.current();
        wait.until(ExpectedConditions.visibilityOf(BookingObject.cureent_co));
        BookingObject.CurrentNationality(CurrentCode);
        Thread.sleep(3000);
        wait.until(ExpectedConditions.visibilityOf(BookingObject.getTravellersSection()));
        BookingObject.FillDataTravells(title,FirstN,LastN, Age,first,Last);
        Thread.sleep(3000);
        wait.until(ExpectedConditions.elementToBeClickable(BookingObject.getPaymentOption(0)));
        BookingObject.Pyment_complite(payment);

        wait.until(ExpectedConditions.visibilityOf(BookingObject.SuccessBooking.get(0)));
        Assert.assertEquals("Payment Time", BookingObject.SuccessBooking.get(0).getText());
    }
}
