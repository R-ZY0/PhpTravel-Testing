package pages;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPage extends PageBase {

	
	

    



	public LoginPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
		// TODO Auto-generated constructor stub
	}



	@FindBy(className = "bodyload")
	WebElement loadingOverlay;
	@FindBy(id="email")
	WebElement emailTxt;
	
	@FindBy(id="password")
	WebElement passwordTxt;
	
	@FindBy(id="submit")
	WebElement loginBtn;
	@FindBy(xpath="/html/body/div[1]/div/div/div/div[3]/small")
	public WebElement loginMessage;
	@FindBy(className="fw-semibold")
	public WebElement successMassege;
	@FindBy(css = "canvas.am5-layer-30")
	public WebElement reportCanvas;
	
	@FindBy(css=".text-start.btn.btn-outline-light.btn-toggle.collapsed.w-100.gap-3")
	 public List <WebElement> reportsButton;

	@FindBy(xpath="//a[contains(text(), 'Weekly Bookings')]")
	public WebElement listReport_First;
	@FindBy(xpath="//a[contains(text(), 'Monthly Bookings')]")
	public WebElement listReport_Second;
	@FindBy(xpath="//a[contains(text(), 'Annually Bookings')]")
	
	public WebElement listReport_Third;
	@FindBy(xpath="//a[contains(text(), 'Weekly Users')]")
	public WebElement listReport_Fourth;
	@FindBy(xpath="//a[contains(text(), 'Monthly Users')]")
	public WebElement listReport_Fifth;
	@FindBy(xpath="//a[contains(text(), 'Annually Users')]")
	public WebElement listReport_Sixth;
	@FindBy(xpath="//a[contains(text(), 'Payment Transactions')]")
	public WebElement listReport_Seventh;
	@FindBy(xpath="//a[contains(text(), 'Annual Income Report')]")
	public WebElement listReport_eighth;

	@FindBy(className="loadeffect.link-light")
	 public List<WebElement> ReportBTN;

	
	
	
	public void enterEmail(String email) {
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    wait.until(ExpectedConditions.visibilityOf(emailTxt)).clear();
	    emailTxt.sendKeys(email);
	}

	public void enterPassword(String password) {
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    wait.until(ExpectedConditions.visibilityOf(passwordTxt)).clear();
	    passwordTxt.sendKeys(password);
	}
	public void clickLogin() {
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    wait.until(ExpectedConditions.elementToBeClickable(loginBtn)).click();
	}
	//
	public void listReport_F() {
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    wait.until(ExpectedConditions.elementToBeClickable(listReport_First)).click();
	}
	public void listReport_S() {
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    wait.until(ExpectedConditions.elementToBeClickable(listReport_Second)).click();
	} 
	public void listReport_T() {
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    wait.until(ExpectedConditions.elementToBeClickable(listReport_Third)).click();
	}
	
	public void listReport_Four() {
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    wait.until(ExpectedConditions.elementToBeClickable(listReport_Fourth)).click();
	}
	public void listReport_Fifth() {
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    wait.until(ExpectedConditions.elementToBeClickable(listReport_Fifth)).click();
	}
	public void listReport_Sixth() {
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    wait.until(ExpectedConditions.elementToBeClickable(listReport_Sixth)).click();
	}
	public void listReport_Seventh() {
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    wait.until(ExpectedConditions.elementToBeClickable(listReport_Seventh)).click();
	}
	public void listReport_eighth() {
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    wait.until(ExpectedConditions.elementToBeClickable(listReport_eighth)).click();
	}
	

	public void userCanLogin(String email, String password) {
	    enterEmail(email);
	    enterPassword(password);
	    clickLogin();
	}

	public void clickReportsBtn() {
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    wait.until(ExpectedConditions.invisibilityOf(loadingOverlay));
	    reportsButton.get(13).click();
	  
	   
	}
	public boolean isCanvasValid() {
        WebElement reportCanvas = driver.findElement(By.cssSelector("canvas.am5-layer-30"));
        Dimension canvasSize = reportCanvas.getSize();
        int width = canvasSize.getWidth();
        int height = canvasSize.getHeight();

        // Assuming 500px height and specific width is required for the canvas to be valid
        return height >= 500 && width == 1262;
    }

    // Method to click on a specific report and check canvas validity
	// Method to check if the canvas element is valid (height >= 500px and width == 1262px)
	public boolean checkReportValidity(WebElement reportElement, String reportName) {
		try {
	        reportElement.click(); // Click the specific report
	        boolean isValid = isCanvasValid(); // Check canvas validity after clicking
	        System.out.println(reportName + " Validity: " + (isValid ? "PASS" : "FAIL"));
	        return isValid;
	    } catch (Exception e) {
	        System.out.println("Error checking " + reportName + " report canvas: " + e.getMessage());
	        return false;
	    }
	}

    // Method to log the results of the canvas validity checks
    public void logResults(boolean[] results, String[] reportNames) {
        for (int i = 0; i < results.length; i++) {
            System.out.println(reportNames[i] + " canvas validity: " + (results[i] ? "PASS" : "FAIL"));
        }
    }
    
	
	
	
	
	
}
