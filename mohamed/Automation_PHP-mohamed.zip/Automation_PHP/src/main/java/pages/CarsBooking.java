package pages;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.JavascriptExecutor;

public class CarsBooking extends PageBase {

	public CarsBooking(WebDriver driver) {
		super(driver);

	}

	@FindBy(css = ".card--item.col-12.col-md-4.col-lg-3")
	List<WebElement> ListOfResult;
	@FindBy(xpath = "//form[@action='https://phptravels.net/cars/booking']//button[@type='submit']")
	List<WebElement> Buttons;
	@FindBy(css = "p[class='mb-0 text-white text-center fw-bold']")
	public WebElement massegeInBooking;
	@FindBy(name = "user[first_name]")
	WebElement FirstNameUser;
	@FindBy(name = "user[last_name]")
	WebElement LastNameUser;
	@FindBy(name = "user[email]")
	WebElement EmailUser;
	@FindBy(name = "user[phone]")
	WebElement PhoneUser;
	@FindBy(name = "user[address]")
	WebElement AddressUser;
	@FindBy(className="nationality.selectpicker.w-100")
	WebElement NationalityUser;
	
	@FindBy(className="country.selectpicker.w-100")
	WebElement CurrentCountryUser;
	
	@FindBy(css = "div.card.mb-3")
	List<WebElement> TravellersInformation;
	@FindBy(id="pills-home-tab")
	List<WebElement> PymentMethod;
	@FindBy(id="agreechb")
	WebElement Agree;
	@FindBy(id="booking")
	WebElement btnBook;
	@FindBy(css=".text-primary.fw-bold")
	public List  <WebElement> SuccessBooking;
	@FindBy(xpath="/html/body/main/div[2]/form/section/div/div/div[1]/div[1]/div[2]/div/div/div[6]/div/div/button")
	 WebElement btnnationality;
	
	@FindBy(xpath="/html/body/main/div[2]/form/section/div/div/div[1]/div[1]/div[2]/div/div/div[7]/div/div/button")
	 WebElement btncurrent;
	
	@FindBy(xpath="/html/body/main/div[2]/form/section/div/div/div[1]/div[1]/div[2]/div/div/div[6]/div/div/div/div[1]/input")
	 public WebElement Nationali;
	
	@FindBy(xpath="/html/body/main/div[2]/form/section/div/div/div[1]/div[1]/div[2]/div/div/div[7]/div/div/div/div[1]/input")
	 public WebElement cureent_co;
	// Returns the specific Book button by index
	public WebElement getBtnBook(int index) {
	    
	    return Buttons.get(index);
	}

	// Returns the first name input field
	public WebElement getFirstNameField() {
	    return FirstNameUser;
	}

	// Returns the whole travellers info section (or any visible field inside it)
	public WebElement getTravellersSection() {
	    return driver.findElement(By.cssSelector("input[name^='firstname_']")); // Adjust to something reliably present
	}

	// Returns a payment option radio/checkbox by index
	public WebElement getPaymentOption(int index) {
	    
	    return PymentMethod.get(index);
	}

	
	
	
	
	
	
	
	
	
	
	

	public void BtnBook(int NumBtn) {

		System.out.println("Number of card items: " + ListOfResult.size());
		System.out.println("Number of booking buttons: " + Buttons.size());
		Buttons.get(NumBtn).click();

	}

	
	public void FillData(String FirstName, String LastName, String Email, String Phone, String address) {
	    FirstNameUser.sendKeys(FirstName);
	    LastNameUser.sendKeys(LastName);
	    EmailUser.sendKeys(Email);
	    PhoneUser.sendKeys(Phone);
	    AddressUser.sendKeys(address);

	    
	}
	public void nationality() {
		btnnationality.click();
	}

	public void matherNationality(String nation) throws InterruptedException {
		Nationali.sendKeys(nation);
		Thread.sleep(1000); // Wait for the dropdown to show
		Nationali.sendKeys(Keys.ARROW_DOWN); // Move to the first result
		Nationali.sendKeys(Keys.ENTER);

	}

	public void current() {
		btncurrent.click();
	}

	public void CurrentNationality(String current_code) throws InterruptedException {
		cureent_co.sendKeys( current_code);
		Thread.sleep(1000); // Wait for the dropdown to show
		cureent_co.sendKeys(Keys.ARROW_DOWN); // Move to the first result
		cureent_co.sendKeys(Keys.ENTER);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("btn = document.getElementById('booking');\r\n"
				+ "if (btn) {\r\n"
				+ "  btn.scrollIntoView({ behavior: \"smooth\" });\r\n"
				+ "}\r\n");

	}

	

		public void Pyment_complite(int numberPymentMethod) {
			PymentMethod.get(numberPymentMethod).click();
			Agree.click();
			btnBook.click();
		}
	
	
	public void FillDataTravells(String titel, String FirstNameA1, String LastNameA1, String Age, String FirstNameC2,
			String LastNameC2) {
		for (WebElement Card : TravellersInformation) {

// Check if this is an adult card
			List<WebElement> adultTitleSelect = Card.findElements(By.cssSelector("select[name^='title_']"));
			List<WebElement> childAgeSelect = Card.findElements(By.cssSelector("select[name^='child_age_']"));

			if (!adultTitleSelect.isEmpty()) {
// === Adult Card ===
				Select titleDropdown = new Select(adultTitleSelect.get(0));
				titleDropdown.selectByVisibleText(titel); // Change as needed

				WebElement firstNameAdult = Card.findElement(By.cssSelector("input[name^='firstname_']"));
				WebElement lastNameAdult = Card.findElement(By.cssSelector("input[name^='lastname_']"));

				firstNameAdult.sendKeys(FirstNameA1);
				lastNameAdult.sendKeys(LastNameA1);

			} else if (!childAgeSelect.isEmpty()) {
// === Child Card ===
				Select ageDropdown = new Select(childAgeSelect.get(0));
				ageDropdown.selectByVisibleText(Age); // Change as needed

				WebElement firstNameChild = Card.findElement(By.cssSelector("input[name^='child_firstname_']"));
				WebElement lastNameChild = Card.findElement(By.cssSelector("input[name^='child_lastname_']"));

				firstNameChild.sendKeys(FirstNameC2);
				lastNameChild.sendKeys(LastNameC2);
			}
		}
	
	
	
	}
	

}
