package pages;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Cars_search_happey extends PageBase {

	public Cars_search_happey(WebDriver driver) {
	    super(driver);
	    PageFactory.initElements(driver, this);
	}

	

	// done
	@FindBy(xpath = "/html/body/main/div[1]/div[2]/div[2]/div/div/ul/li[4]/button")
	public WebElement BtnCars;
	// done
	@FindBy(css = "span#select2--container")
	List<WebElement> elements;
	@FindBy(className = "select2-search__field")

	public WebElement inputFrom_To;

	// done
	@FindBy(id = "cars_from_date")
	WebElement PickUpDate;
	// done
	@FindBy(id = "cars_from_time")
	WebElement PickUpTime;
	// done
	@FindBy(id = "cars_to_date")
	WebElement DropOffDate;
	// done
	@FindBy(id = "cars_to_time")
	WebElement DropOfTime;
	// done
	@FindBy(css = "strong.mt-1")
	public WebElement InCarsMassege;

	@FindBy(xpath = "//*[@id=\"cars-search\"]/div/div[5]/div/div/div/a")
	WebElement Travellers;

	@FindBy(className = "qtyInc")
	public List<WebElement> add;
	@FindBy(className = "qtyDec")
	public List<WebElement> sub;

	@FindBy(id = "cars_adults")
	public WebElement resultAdults;
	@FindBy(id = "cars_child")
	public WebElement resultChilds;
	@FindBy(className = "guest_cars")
	public WebElement TotalResult;
	@FindBy(xpath = "//*[@id=\"fadein\"]/main/div[4]/div/div/div[1]/div/div[2]/form/button")
	public WebElement SearchRe;

	// done
	@FindBy(xpath = "/html/body/main/div[1]/div[2]/div[2]/div/div/div/div/div[4]/form/div/div[6]/button")
	public WebElement BtnSearchButton;

	public void clickToCars() {
		BtnCars.click();
	}

	public void BtnSearch() {
		BtnSearchButton.click();
	}

	public void FillData(String PickupDate, int PickupTime, String DropoffDate, int DropofTime) {
		PickUpDate.sendKeys(PickupDate);
		// DropDown list PickUpTime
		Select PickUp = new Select(PickUpTime);
		List<WebElement> options = PickUp.getOptions();
		PickUp.selectByIndex(PickupTime);
		// DropDown list DropOfTime
		Select DropOff = new Select(DropOfTime);
		List<WebElement> option = DropOff.getOptions();
		DropOff.selectByIndex(DropofTime);
		DropOffDate.sendKeys(DropoffDate);

	}

	public void TravellerDropdownIn(int numAdults, int numChildren) {
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    JavascriptExecutor js = (JavascriptExecutor) driver;

	    if (add != null && add.size() > 9) {
	        for (int i = 0; i < numAdults; i++) {
	            WebElement adultBtn = wait.until(ExpectedConditions.elementToBeClickable(add.get(8)));
	            try {
	                adultBtn.click();
	            } catch (ElementNotInteractableException e) {
	                js.executeScript("arguments[0].click();", adultBtn);
	            }
	        }

	        for (int i = 0; i < numChildren; i++) {
	            WebElement childBtn = wait.until(ExpectedConditions.elementToBeClickable(add.get(9)));
	            try {
	                childBtn.click();
	            } catch (ElementNotInteractableException e) {
	                js.executeScript("arguments[0].click();", childBtn);
	            }
	        }
	    }
	}

	public void TravellerDropdownDec(int numAdults, int numChildren) {
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    JavascriptExecutor js = (JavascriptExecutor) driver;

	    if (sub != null && sub.size() > 9) {
	        for (int i = 0; i < numAdults; i++) {
	            WebElement adultBtn = wait.until(ExpectedConditions.elementToBeClickable(sub.get(8)));
	            try {
	                adultBtn.click();
	            } catch (ElementNotInteractableException e) {
	                js.executeScript("arguments[0].click();", adultBtn);
	            }
	        }

	        for (int i = 0; i < numChildren; i++) {
	            WebElement childBtn = wait.until(ExpectedConditions.elementToBeClickable(sub.get(9)));
	            try {
	                childBtn.click();
	            } catch (ElementNotInteractableException e) {
	                js.executeScript("arguments[0].click();", childBtn);
	            }
	        }
	    }
	}

	public void dropFrom() {
		elements.get(0).click();
	}

	public void FromAirport(String from) throws InterruptedException {
		inputFrom_To.sendKeys(from);
		Thread.sleep(1000); // Wait for the dropdown to show
		inputFrom_To.sendKeys(Keys.ARROW_DOWN); // Move to the first result
		inputFrom_To.sendKeys(Keys.ENTER);

	}

	public void dropTo() {
		elements.get(1).click();
	}

	public void ToLocation(String To) throws InterruptedException {
		inputFrom_To.sendKeys(To);
		Thread.sleep(1000); // Wait for the dropdown to show
		inputFrom_To.sendKeys(Keys.ARROW_DOWN); // Move to the first result
		inputFrom_To.sendKeys(Keys.ENTER);

	}

	public void Tr() {
		Travellers.click();
	}

}
