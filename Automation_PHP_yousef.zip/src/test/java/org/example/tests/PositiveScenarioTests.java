package org.example.tests;

import org.example.base.TestBase;
import org.example.pages.*;
import org.testng.Assert;
import org.testng.annotations.Test;

public class PositiveScenarioTests extends TestBase {

    HomePage homePage;
    SearchResultsPage searchResultsPage;
    HotelDetailsPage hotelDetailsPage;
    BookingFormPage bookingFormPage;
    InvoicePage invoicePage;

    @Test(description = "Test end-to-end hotel booking flow.")
    public void testFullHotelBookingFlow() throws InterruptedException {
        homePage = new HomePage(driver);

        // --- Part 1: Search for Hotel (from Book_test.java) ---
        System.out.println("STEP 1: Starting Hotel Search...");
        homePage.navigateToHotelsTab();
        Thread.sleep(500); // Small pause
        homePage.selectCity("Dubai"); // "Phuket" was in old code, "Dubai" in assertion. Using Dubai.
        Thread.sleep(500);
        homePage.enterCheckinDate("10-05-2026");
        homePage.enterCheckoutDate("11-05-2026");
        Thread.sleep(500);
        homePage.setTravellers("1", "1"); // Adults: 1, Rooms: 1 based on your Fill_out_the_form URL
        Thread.sleep(500);
        homePage.selectNationality("EG");
        Thread.sleep(2000); // As requested: "between each on 2s" (applying after major step)

        searchResultsPage = homePage.clickSearchButton();
        System.out.println("STEP 1: Hotel Search Submitted.");
        Assert.assertTrue(searchResultsPage.getPageTitle().contains("Hotels"), "Not on search results page after search.");
        Assert.assertTrue(searchResultsPage.areHotelsDisplayed(), "Hotel search results are not displayed.");
        Thread.sleep(2000);

        // --- Part 2: Choose Hotel (from choose_hotel.java) ---
        System.out.println("STEP 2: Selecting Hotel...");
        String searchResultsURL = searchResultsPage.getCurrentUrl();
        hotelDetailsPage = searchResultsPage.selectFirstHotelAndViewDetails();
        System.out.println("STEP 2: Hotel Selected.");

        Assert.assertNotEquals(hotelDetailsPage.getPageTitle(), searchResultsURL, "URL did not change after selecting hotel.");
        Assert.assertTrue(hotelDetailsPage.getCurrentUrl().contains("/hotel/"), "Not on hotel details page.");
        Assert.assertTrue(hotelDetailsPage.isHotelNameDisplayed(), "Hotel name is not displayed on details page.");
        System.out.println("Hotel Name on Details Page: " + hotelDetailsPage.getDisplayedHotelName());
        Thread.sleep(2000);

        // --- Part 3: Fill out Form (from Fill_out_the_form.java) ---
        // The HotelDetailsPage now needs to navigate to BookingFormPage
        System.out.println("STEP 3: Initiating Room Booking...");
        bookingFormPage = hotelDetailsPage.clickBookNowForARoom(); // This was the first click in your old Fill_out_the_form
        Thread.sleep(500); // Wait for form to load
        System.out.println("STEP 3: Booking Form Page Reached.");

        System.out.println("Filling booking form...");
        bookingFormPage.fillPersonalInformation("Yousef", "Amr", "Oseyamr844@gmail.com", "01122490646", "Giza Egypt");
        Thread.sleep(500);
        bookingFormPage.fillTravellerInformation("Mr", "Yousef", "Amr");
        Thread.sleep(500);
        bookingFormPage.selectPaymentMethodAsBankTransfer();
        Thread.sleep(500);
        bookingFormPage.agreeToTermsAndConditions();
        Thread.sleep(2000);

        invoicePage = bookingFormPage.clickBookingConfirm();
        System.out.println("STEP 3: Booking Confirmed.");
        Thread.sleep(500);

        Assert.assertTrue(invoicePage.isInvoicePageLoaded(), "Failed to load the invoice page or title is incorrect.");
        System.out.println("Successfully booked hotel and landed on Invoice Page. Test Passed!");
    }
}