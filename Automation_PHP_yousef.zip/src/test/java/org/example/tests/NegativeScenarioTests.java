package org.example.tests;

import org.example.base.TestBase;
import org.example.pages.HomePage;
import org.example.pages.SearchResultsPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class NegativeScenarioTests extends TestBase {

    HomePage homePage;

    @Test(description = "Test hotel search without filling required fields.")
    public void testSearchWithoutRequiredFields() throws InterruptedException {
        homePage = new HomePage(driver);

        System.out.println("Starting negative scenario: Search without required fields...");
        homePage.navigateToHotelsTab();
        Thread.sleep(500);

        System.out.println("Clicking search button without filling mandatory fields...");
        homePage.clickSearchButton(); // This might navigate or show an error on the same page
        Thread.sleep(1000); // Wait for potential error messages or page reaction

        Assert.assertTrue(driver.getCurrentUrl().contains(baseURL) || driver.getCurrentUrl().endsWith("#"),
                "Page should not have navigated away from home or should show an error on the same page.");


        System.out.println("Negative scenario test completed. Verify assertions based on actual application behavior.");

    }
}