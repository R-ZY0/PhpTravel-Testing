package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.time.Duration;

public class Fill_out_the_form {
    String BaseURL = "https://phptravels.net/hotel/143564/al-jawhara-metro-hotel/10-05-2026/11-05-2026/1/1/0/EG/stuba";
    WebDriver driver;
    WebDriverWait wait;


    @BeforeTest
    public void beforeTestSetup() {
        // System.setProperty("webdriver.chrome.driver", "path/to/chromedriver.exe"); // If needed
        driver = new ChromeDriver();
        driver.manage().window().maximize(); // Good practice
        // Initialize WebDriverWait AFTER driver is initialized
        wait = new WebDriverWait(driver, Duration.ofSeconds(20)); // Adjust timeout as needed
        driver.navigate().to(BaseURL);
        try {
            // An initial wait for the page to likely be ready after navigation.
            // Replace with a more specific wait for an element if possible.
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            e.printStackTrace();
        }
    }
    @Test
    public void fill_out_form() throws InterruptedException { // Added InterruptedException
        try {
            System.out.println("Starting fill_out_form test...");

            // 1. Click the first "Book Now" button for a room
            By bookNowButtonRoomLocator = By.xpath("(//td[contains(@style, 'background-color: #e6e7eb')]//button[normalize-space(.)='Book Now'])[1]");
            WebElement bookNowRoomButton = wait.until(ExpectedConditions.elementToBeClickable(bookNowButtonRoomLocator));
            bookNowRoomButton.click();
            System.out.println("Clicked on the first 'Book Now' button for a room.");

            // 2. Wait 0.5 seconds (500 milliseconds)
            Thread.sleep(500);

            // 3. Wait for Personal Information form elements to be visible and fill them
            System.out.println("Filling Personal Information...");
            WebElement firstNameInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("user[first_name]")));
            firstNameInput.sendKeys("Yousef");

            WebElement lastNameInput = driver.findElement(By.name("user[last_name]"));
            lastNameInput.sendKeys("Amr");

            WebElement emailInput = driver.findElement(By.name("user[email]"));
            emailInput.sendKeys("Oseyamr844@gmail.com");

            WebElement phoneInput = driver.findElement(By.id("phone")); // Using ID as it's more specific
            phoneInput.sendKeys("01122490646");

            WebElement addressInput = driver.findElement(By.name("user[address]"));
            addressInput.sendKeys("Giza Egypt");

            // Nationality and Country are assumed to be pre-filled by the page (value="EG")
            System.out.println("Personal Information filled.");
            Thread.sleep(500);
            // 4. Fill Travellers Information (Adult 1)
            System.out.println("Filling Travellers Information...");
            WebElement titleDropdown = wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("title_1")));
            Select titleSelect = new Select(titleDropdown);
            titleSelect.selectByValue("Mr");

            WebElement travellerFirstNameInput = driver.findElement(By.name("firstname_1"));
            travellerFirstNameInput.sendKeys("Yousef");

            WebElement travellerLastNameInput = driver.findElement(By.name("lastname_1"));
            travellerLastNameInput.sendKeys("Amr");
            System.out.println("Travellers Information filled.");

            // 5. Select Payment Method: "Pay With bank transfer"
            System.out.println("Selecting Payment Method...");

            Thread.sleep(500);
            WebElement bankTransferRadio = wait.until(ExpectedConditions.elementToBeClickable(By.id("gateway_bank_transfer")));
            bankTransferRadio.click();
            System.out.println("Selected 'Bank Transfer'.");
            Thread.sleep(500);
            // 6. Agree to Terms & Conditions
            System.out.println("Agreeing to Terms & Conditions...");
            WebElement agreeCheckbox = wait.until(ExpectedConditions.elementToBeClickable(By.id("agreechb")));
            if (!agreeCheckbox.isSelected()) { // Click only if not already selected
                agreeCheckbox.click();
            }
            System.out.println("Agreed to Terms & Conditions.");

            // 7. Wait 0.5 seconds
            Thread.sleep(500);

            // 8. Click "Booking Confirm" button
            System.out.println("Attempting to click 'Booking Confirm'...");
            By bookingConfirmButtonLocator = By.id("booking");
            WebElement bookingConfirmButton = wait.until(ExpectedConditions.elementToBeClickable(bookingConfirmButtonLocator));
            Assert.assertTrue(bookingConfirmButton.isEnabled(), "Booking Confirm button is not enabled after agreeing to terms.");
            bookingConfirmButton.click();
            System.out.println("Clicked 'Booking Confirm'.");

            // 9. Wait 0.5 seconds
            Thread.sleep(500);

            // 10. Verify page title contains "Hotels Invoice"
            System.out.println("Verifying invoice page title...");
            boolean titleCorrect = wait.until(ExpectedConditions.titleContains("Hotels Invoice"));
            Assert.assertTrue(titleCorrect, "Page title does not contain 'Hotels Invoice'. Actual title: " + driver.getTitle());
            System.out.println("Test Passed! Navigated to Hotels Invoice page.");

        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt(); // Restore interruption status
            System.err.println("Test was interrupted: " + ie.getMessage());
            ie.printStackTrace();
            Assert.fail("Test interrupted: " + ie.getMessage());
        } catch (Exception e) {
            System.err.println("Test failed due to an exception: " + e.getMessage());
            e.printStackTrace();
            Assert.fail("Test failed due to an exception: " + e.getMessage());
        }
    }

    @AfterTest
    public void afterTestTearDown() {
        if (driver != null) {
            System.out.println("Closing the browser.");
            driver.quit();
        }
    }
}