package org.example.base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import java.time.Duration;

public class TestBase {

    public WebDriver driver; // Changed to public or protected to be accessible by test classes
    public WebDriverWait wait; // Changed to public or protected
    public String baseURL = "https://phptravels.net/";

    @BeforeTest
    public void beforeTestSetup() {
        // Ensure ChromeDriver is in your PATH or set the property:
        // System.setProperty("webdriver.chrome.driver", "path/to/chromedriver.exe");
        // Or use WebDriverManager.chromedriver().setup(); if you add the dependency

        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5)); // Basic implicit wait

        wait = new WebDriverWait(driver, Duration.ofSeconds(20)); // Default explicit wait timeout

        driver.navigate().to(baseURL);
        System.out.println("Navigated to Base URL: " + baseURL);

        try {
            // Initial pause for the page to settle - can be replaced by specific waits in HomePage
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            e.printStackTrace();
        }
    }

    @AfterTest
    public void afterTestTearDown() {
        if (driver != null) {
            System.out.println("Closing the browser.");
            driver.quit();
        }
    }
}