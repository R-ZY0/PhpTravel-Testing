package org.example;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.openqa.selenium.By;

import java.util.List;

import static org.testng.Assert.assertEquals;
import static org.testng.AssertJUnit.assertTrue;

public class Book_test {
    String BaseURL = "https://phptravels.net/#";
    WebDriver driver;

    @BeforeTest
    public void beforeTestSetup() {
        // 1. حدد مكان geckodriver قبل الإنشاء
//        System.setProperty("webdriver.gecko.driver", "C:\\Program Files\\geckodriver.exe");

        // 2. بعدين أنشئ الـ Driver
        driver = new ChromeDriver();

        // 3. انتقل إلى الموقع
        driver.navigate().to(BaseURL);
    }

    @Test
    public void click_search() {
        try {
            driver.findElement(By.xpath("//*[@id=\"tab\"]/li[2]/button")).click();
            Thread.sleep(2000);
            // 1. اضغط على القائمة المنسدلة للمدن
            WebElement dropdown = driver.findElement(By.xpath("//*[@id=\"select2-hotels_city-container\"]"));
            dropdown.click();
            Thread.sleep(2000);
            // 2. اختر مدينة "Phuket"
            WebElement cityOption = driver.findElement(By.xpath("//*[@id=\"select2-hotels_city-results\"]/div/div[1]"));
            cityOption.click();


            String selectedText = dropdown.getText().trim();

            Assert.assertTrue(selectedText.contains("Dubai"), "City should be Dubai but was: " + selectedText);
            Thread.sleep(1000); // يفضل تغييره لاحقًا بـ WebDriverWait
            // 4. اختار تاريخ Check-in
            WebElement checkin = driver.findElement(By.id("checkin"));
            checkin.clear();
            checkin.sendKeys("10-05-2026");

            // 5. اختار تاريخ Check-out
            WebElement checkout = driver.findElement(By.id("checkout"));
            checkout.clear();
            checkout.sendKeys("11-05-2026");
            Thread.sleep(2000);
            // 6. تحقق من القيم المختارة
            assertEquals(checkin.getAttribute("value"), "10-05-2026");
            assertEquals(checkout.getAttribute("value"), "11-05-2026");
            Thread.sleep(2000); // انتظار بسيط لتحميل المحتوى

            // افتح القائمة المنسدلة
            WebElement travellersDropdown = driver.findElement(By.xpath("//*[@id=\"hotels-search\"]/div/div[4]/div/div/div/a"));
            travellersDropdown.click();

            Thread.sleep(500); // انتظار بسيط لتحميل المحتوى

            // إدخال عدد البالغين مباشرة
            WebElement adultsInput = driver.findElement(By.id("hotels_adults"));
            adultsInput.clear();
            adultsInput.sendKeys("2");

            // إدخال عدد الغرف مباشرة
            WebElement roomsInput = driver.findElement(By.id("hotels_rooms"));
            roomsInput.clear();
            roomsInput.sendKeys("1");
            Thread.sleep(500); // انتظار بسيط لتحميل المحتوى

            // اختيار الجنسية
            Select nationalityDropdown = new Select(driver.findElement(By.id("nationality")));
            nationalityDropdown.selectByValue("EG"); // اختيار مصر مثلاً
            // تحقق من القيمة
            WebElement adultInput = driver.findElement(By.id("hotels_adults"));
            WebElement roomInput = driver.findElement(By.id("hotels_rooms"));
            Thread.sleep(1000); // انتظار بسيط لتحميل المحتوى

            assertEquals("2", adultInput.getAttribute("value"));
            assertEquals("1", roomInput.getAttribute("value"));
            travellersDropdown.click();
// الضغط على زر البحث باستخدام XPath
            WebElement searchButton = driver.findElement(By.xpath("//*[@id=\"hotels-search\"]/div/div[5]/button"));
            searchButton.click();

            // الانتظار حتى يتم تحميل الصفحة
            Thread.sleep(2000); // يفضل استخدام WebDriverWait بدلًا من sleep في المشاريع الحقيقية

            // التحقق أن عنوان الصفحة يحتوي على Hotels
            String pageTitle = driver.getTitle();
            assertTrue("Expected title to contain 'Hotels'", pageTitle.contains("Hotels"));
            // الانتظار حتى يتم تحميل الصفحة
            Thread.sleep(2000); // يفضل استخدام WebDriverWait بدلًا من sleep في المشاريع الحقيقية

        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


//    @Test (enabled = true)
//    public void delete_and_click_link() {
//        try {
//            // Wait for additional content to load.
//            driver.navigate().to("https://phptravels.net/hotels/dubai/14-05-2025/24-05-2025/1/2/0/US");
//            // Find and collect all hotel-related links.
//            Thread.sleep(3000);
//            List<WebElement> viewMoreLinks = driver.findElements(By.cssSelector("a[href*='hotel']"));
//
//            // Click on the first link if it exists.
//            if (!viewMoreLinks.isEmpty()) {
//                viewMoreLinks.get(0).click();
//
//                // Wait for navigation to complete.
//                Thread.sleep(2000); // Preferable to replace with WebDriverWait.
//
//                // Validate the page title has changed.
//                String newPageTitle = driver.getTitle();
//                assertTrue("Page title should change after clicking a hotel link.", !newPageTitle.isEmpty());
//            } else {
//                Assert.fail("No links found containing 'hotels' in href attribute.");
//            }
//
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }


    @AfterTest
    public void afterTestTearDown() {
        driver.quit();
    }
}
