package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.time.Duration; // Import Duration
import java.util.List;

import static org.testng.AssertJUnit.assertTrue;

public class choose_hotel {
    String BaseURL = "https://phptravels.net/hotels/dubai/10-05-2026/11-05-2026/1/1/0/EG";
    WebDriver driver;

    @BeforeTest
    public void beforeTestSetup() {
        // 1. حدد مكان geckodriver قبل الإنشاء
//        System.setProperty("webdriver.gecko.driver", "C:\\Program Files\\geckodriver.exe");

        // 2. بعدين أنشئ الـ Driver
        driver = new ChromeDriver();

        // 3. انتقل إلى الموقع
        driver.navigate().to(BaseURL);
    }




    @Test
    public void chose_hotel_test() {
        // 1. Wait for hotel results to be displayed
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20)); // Increased wait time for reliability
        By hotelListLocator = By.cssSelector("li.card--item.ng-scope");

        try {
            wait.until(ExpectedConditions.presenceOfElementLocated(hotelListLocator));
            System.out.println("Hotel list items are present.");

            // 2. Get all displayed hotel items
            List<WebElement> hotelItems = driver.findElements(hotelListLocator);

            // 3. Check if any hotel is found
            Assert.assertTrue(hotelItems.size() > 0, "No hotels found on the results page.");
            System.out.println("Found " + hotelItems.size() + " hotel(s).");

            // 4. Select the first hotel from the results.
            WebElement firstHotelItem = hotelItems.get(0);

            By viewMoreButtonLocator = By.cssSelector("a.btn.btn-primary[href*='hotel/']");
            // Alternative XPath: .//a[contains(normalize-space(), 'View More') and contains(@class, 'btn-primary')]

            WebElement viewMoreButton = firstHotelItem.findElement(viewMoreButtonLocator);
            Assert.assertNotNull(viewMoreButton, "View More button not found for the first hotel.");
            System.out.println("View More button found for the first hotel.");

            // Store the current URL before clicking, to verify navigation
            String searchResultsURL = driver.getCurrentUrl();

            // 6. Click "View More"
            wait.until(ExpectedConditions.elementToBeClickable(viewMoreButton));
            viewMoreButton.click();
            System.out.println("Clicked on the 'View More' button.");

            // 7. Wait for the page to navigate to the hotel details page.
            wait.until(ExpectedConditions.not(ExpectedConditions.urlToBe(searchResultsURL)));
            wait.until(ExpectedConditions.urlContains("/hotel/")); // Check if "hotel" is in the new URL path

            String hotelDetailsURL = driver.getCurrentUrl();
            System.out.println("Navigated to Hotel Details URL: " + hotelDetailsURL);

            // 8. Verify navigation
            Assert.assertNotEquals(hotelDetailsURL, searchResultsURL, "URL did not change after clicking 'View More'.");
            Assert.assertTrue(hotelDetailsURL.contains("/hotel/"), "The new URL does not seem to be a hotel details page.");

            System.out.println("Successfully navigated to the hotel details page. Test Passed!");

        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("Test failed due to an exception: " + e.getMessage());
        }
    }

    @AfterTest
    public void afterTestTearDown() {
        driver.quit();
    }
}
