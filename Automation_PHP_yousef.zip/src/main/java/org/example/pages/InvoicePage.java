package org.example.pages;

import org.example.base.PageBase;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class InvoicePage extends PageBase {

    public InvoicePage(WebDriver driver) {
        super(driver);
    }

    public boolean isInvoicePageLoaded() {
        // Verifies if the title contains "Hotels Invoice"
        System.out.println("Waiting for Invoice Page to load by checking title...");
        try {
            return wait.until(ExpectedConditions.titleContains("Hotels Invoice"));
        } catch (Exception e) {
            System.err.println("Invoice page title not found. Current title: " + driver.getTitle());
            return false;
        }
    }

    // You can add more methods here to verify specific invoice details if needed
}