package org.example.pages;

import org.example.base.PageBase;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.util.List;

public class SearchResultsPage extends PageBase {

    // Locator for the list of hotel cards
    @FindBy(css = "li.card--item.ng-scope")
    private List<WebElement> hotelListItems;

    // More specific locator for the "View More" button within the first hotel item
    // This assumes we always want the first hotel.
    // If more dynamic selection is needed, this would be a method parameter.
    private By firstHotelViewMoreButtonLocator = By.xpath("(//li[contains(@class, 'card--item')]//a[contains(@class, 'btn-primary') and contains(@href, 'hotel/')])[1]");


    public SearchResultsPage(WebDriver driver) {
        super(driver);
    }

    public boolean areHotelsDisplayed() {
        try {
            waitForVisibility(hotelListItems.get(0)); // Wait for the first item to be visible
            return hotelListItems.size() > 0;
        } catch (Exception e) {
            return false;
        }
    }

    public int getHotelCount() {
        if (areHotelsDisplayed()) {
            return hotelListItems.size();
        }
        return 0;
    }

    public HotelDetailsPage selectFirstHotelAndViewDetails() {
        System.out.println("Selecting the first hotel and viewing details...");
        if (!areHotelsDisplayed()) {
            throw new IllegalStateException("No hotels are displayed to select.");
        }
        WebElement viewMoreButton = wait.until(ExpectedConditions.elementToBeClickable(firstHotelViewMoreButtonLocator));
        scrollToElement(viewMoreButton); // Ensure it's in view
        clickElement(viewMoreButton);
        return new HotelDetailsPage(driver);
    }


}