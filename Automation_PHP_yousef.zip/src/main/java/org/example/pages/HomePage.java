package org.example.pages;

import org.example.base.PageBase;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

public class HomePage extends PageBase {

    @FindBy(xpath = "//*[@id=\"tab\"]/li[2]/button")
    private WebElement hotelsTabButton;

    // For Select2 City dropdown - this requires special handling
    @FindBy(xpath = "//*[@id=\"select2-hotels_city-container\"]")
    private WebElement cityDropdownContainer;

    @FindBy(xpath = "/html/body/span/span/span[1]/input") // This is typical for Select2 search input
    private WebElement citySearchInput;

    @FindBy(id = "checkin")
    private WebElement checkinDateField;

    @FindBy(id = "checkout")
    private WebElement checkoutDateField;

    @FindBy(xpath = "//*[@id=\"hotels-search\"]/div/div[4]/div/div/div/a")
    private WebElement travellersDropdownTrigger;

    @FindBy(id = "hotels_adults")
    private WebElement adultsInput;

    @FindBy(id = "hotels_rooms")
    private WebElement roomsInput;

    @FindBy(id = "nationality")
    private WebElement nationalityDropdownElement; // The actual <select>

    @FindBy(xpath = "//*[@id=\"hotels-search\"]/div/div[5]/button")
    private WebElement searchButton;

    public HomePage(WebDriver driver) {
        super(driver);
    }

    public void navigateToHotelsTab() {
        System.out.println("Navigating to Hotels tab...");
        clickElement(hotelsTabButton);
    }

    public void selectCity(String cityName) {
        System.out.println("Selecting city: " + cityName);
        clickElement(cityDropdownContainer);
        // For Select2, after clicking the container, a search input often appears
        // and then you type and select from dynamic results.
        waitForVisibility(citySearchInput);
        typeText(citySearchInput, cityName);
        // Wait for the option with the city name to appear and click it
        // This locator needs to be specific to how your Select2 options are rendered
        WebElement cityOption = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//li[contains(@class, 'select2-results__option') and contains(text(), '" + cityName + "')]")
        ));
        clickElement(cityOption);
    }

    public void enterCheckinDate(String date) {
        System.out.println("Entering check-in date: " + date);
        // Checkin fields on this site might not be standard inputs,
        // they might open a datepicker. Direct sendKeys might work if they are simple text inputs.
        // For this site, direct sendKeys after clear often works.
        typeText(checkinDateField, date);
        // clickElement(hotelsTabButton); // To close datepicker if it stays open
    }

    public void enterCheckoutDate(String date) {
        System.out.println("Entering check-out date: " + date);
        typeText(checkoutDateField, date);
        // clickElement(hotelsTabButton); // To close datepicker if it stays open
    }

    public void setTravellers(String adults, String rooms) {
        System.out.println("Setting travellers - Adults: " + adults + ", Rooms: " + rooms);
        clickElement(travellersDropdownTrigger); // Open the dropdown
        waitForVisibility(adultsInput);
        typeText(adultsInput, adults);
        typeText(roomsInput, rooms);
//        clickElement(travellersDropdownTrigger); // Close the dropdown
    }

    public void selectNationality(String nationalityValue) {
        System.out.println("Selecting nationality: " + nationalityValue);
        // This is a standard select, but it's within the travellers dropdown,
        // ensure travellersDropdownTrigger was clicked if it's not always visible
        waitForVisibility(nationalityDropdownElement);
        Select select = new Select(nationalityDropdownElement);
        select.selectByValue(nationalityValue);
    }

    public SearchResultsPage clickSearchButton() {
        System.out.println("Clicking hotel search button...");
        clickElement(searchButton);
        return new SearchResultsPage(driver);
    }
}