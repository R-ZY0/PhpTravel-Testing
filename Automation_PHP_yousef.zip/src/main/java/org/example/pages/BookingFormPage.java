package org.example.pages;

import org.example.base.PageBase;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class BookingFormPage extends PageBase {

    @FindBy(name = "user[first_name]")
    private WebElement firstNameInput;

    @FindBy(name = "user[last_name]")
    private WebElement lastNameInput;

    @FindBy(name = "user[email]")
    private WebElement emailInput;

    @FindBy(id = "phone")
    private WebElement phoneInput;

    @FindBy(name = "user[address]")
    private WebElement addressInput;

    // Nationality and Country are usually pre-filled or handled via JS based on context.
    // If direct interaction is needed, their specific locators for Bootstrap select would be required.

    @FindBy(name = "title_1")
    private WebElement travellerTitleDropdown;

    @FindBy(name = "firstname_1")
    private WebElement travellerFirstNameInput;

    @FindBy(name = "lastname_1")
    private WebElement travellerLastNameInput;

    @FindBy(id = "gateway_bank_transfer")
    private WebElement bankTransferRadio;

    @FindBy(css = "label[for='gateway_bank_transfer']") // For clicking the label
    private WebElement bankTransferLabel;


    @FindBy(id = "agreechb")
    private WebElement agreeCheckbox;

    @FindBy(id = "booking")
    private WebElement bookingConfirmButton;

    public BookingFormPage(WebDriver driver) {
        super(driver);
    }

    public void fillPersonalInformation(String fName, String lName, String email, String phone, String address) {
        System.out.println("Filling personal information...");
        typeText(firstNameInput, fName);
        typeText(lastNameInput, lName);
        typeText(emailInput, email);
        typeText(phoneInput, phone);
        typeText(addressInput, address);
    }

    public void fillTravellerInformation(String title, String fName, String lName) {
        System.out.println("Filling traveller information...");
        waitForVisibility(travellerTitleDropdown);
        new Select(travellerTitleDropdown).selectByValue(title);
        typeText(travellerFirstNameInput, fName);
        typeText(travellerLastNameInput, lName);
    }

    public void selectPaymentMethodAsBankTransfer() {
        System.out.println("Selecting Bank Transfer payment method...");
        scrollToElement(bankTransferLabel); // Scroll label into view
        clickElement(bankTransferLabel); // Clicking label often works better for styled radios
    }

    public void agreeToTermsAndConditions() {
        System.out.println("Agreeing to terms and conditions...");
        scrollToElement(agreeCheckbox);
        if (!agreeCheckbox.isSelected()) {
            // Sometimes a direct click on checkbox is better, sometimes label.
            // If issues, try clicking a label associated with it if one exists,
            // or use Javascript click as a last resort.
            clickElement(agreeCheckbox);
        }
    }

    public InvoicePage clickBookingConfirm() {
        System.out.println("Clicking Booking Confirm button...");
        waitForVisibility(bookingConfirmButton);
        scrollToElement(bookingConfirmButton);
        // The button gets enabled by JS, ensure it's clickable
        waitForClickability(bookingConfirmButton);
        if (!bookingConfirmButton.isEnabled()) {
            // Add a small dynamic wait for it to be enabled if needed
            try { Thread.sleep(1000); } catch (InterruptedException e) { Thread.currentThread().interrupt();}
        }
        clickElement(bookingConfirmButton);
        return new InvoicePage(driver);
    }
}