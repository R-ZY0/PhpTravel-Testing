package org.example.pages;

import org.example.base.PageBase;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class HotelDetailsPage extends PageBase {

    // Locator for the first "Book Now" button for a room type
    // (//td[contains(@style, 'background-color: #e6e7eb')]//button[normalize-space(.)='Book Now'])[1]
    @FindBy(xpath = "(//button[normalize-space(.)='Book Now' and contains(@class,'btn-primary')])[1]")
    private WebElement firstBookNowButton;
    // Note: The XPath above is simplified. If the style attribute is crucial, use the original:
    // @FindBy(xpath = "(//td[contains(@style, 'background-color: #e6e7eb')]//button[normalize-space(.)='Book Now'])[1]")

    @FindBy(css = "div.d-md-flex div.h4.fw-bold.mb-0 strong") // From your previous test
    private WebElement hotelNameTitleOnDetailsPage;


    public HotelDetailsPage(WebDriver driver) {
        super(driver);
    }

    public boolean isHotelNameDisplayed() {
        waitForVisibility(hotelNameTitleOnDetailsPage);
        return hotelNameTitleOnDetailsPage.isDisplayed();
    }

    public String getDisplayedHotelName() {
        if (isHotelNameDisplayed()) {
            return hotelNameTitleOnDetailsPage.getText();
        }
        return "";
    }

    public BookingFormPage clickBookNowForARoom() {
        System.out.println("Clicking 'Book Now' for a room...");
        waitForVisibility(firstBookNowButton);
        scrollToElement(firstBookNowButton);
        clickElement(firstBookNowButton);
        return new BookingFormPage(driver);
    }
}