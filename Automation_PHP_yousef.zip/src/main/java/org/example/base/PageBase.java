package org.example.base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.JavascriptExecutor; // Added for scrolling

import java.time.Duration;

public class PageBase {
    protected WebDriver driver;
    protected WebDriverWait wait; // Each page can have its own wait or inherit
    protected JavascriptExecutor jsExecutor; // For scrolling

    public PageBase(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15)); // Default wait for page elements
        this.jsExecutor = (JavascriptExecutor) driver;
        PageFactory.initElements(driver, this); // Critical for @FindBy annotations
    }

    protected void waitForVisibility(WebElement element) {
        wait.until(ExpectedConditions.visibilityOf(element));
    }

    protected void waitForClickability(WebElement element) {
        wait.until(ExpectedConditions.elementToBeClickable(element));
    }

    protected void clickElement(WebElement element) {
        waitForVisibility(element);
        waitForClickability(element);
        element.click();
    }

    protected void typeText(WebElement element, String text) {
        waitForVisibility(element);
        element.clear();
        element.sendKeys(text);
    }

    protected void scrollToElement(WebElement element) {
        jsExecutor.executeScript("arguments[0].scrollIntoView({behavior: 'auto', block: 'center', inline: 'center'});", element);
        try { Thread.sleep(300); } catch (InterruptedException e) { Thread.currentThread().interrupt(); } // Short pause
    }

    public String getPageTitle() {
        return driver.getTitle();
    }

    // ADD THIS METHOD
    public String getCurrentUrl() {
        return driver.getCurrentUrl();
    }
}