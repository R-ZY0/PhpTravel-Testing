package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPage extends PageBase {

	public LoginPage(WebDriver driver) {
		super(driver);
	}
	
	@FindBy(id="email")
	WebElement emailTxt;
	
	@FindBy(id="password")
	WebElement passwordTxt;
	
	@FindBy(id="submitBTN")
	WebElement loginBtn;
	@FindBy(xpath="/html/body/main/div[1]/form/div/div/div/h4")
	public WebElement loginMessage;
	@FindBy(xpath="/html/body/main/div/div/div/div/div[1]/div/div[1]/div/p/small")
	public WebElement successMassege;
	@FindBy(css=".logo")
	WebElement gotohome;
	
	@FindBy(xpath="/html/body/main/div[1]/div[2]/div[1]/h4/strong")
	public WebElement home;
	
	public void userCanLogin(String email,String password) {
		emailTxt.sendKeys(email);
		passwordTxt.sendKeys(password);
		
		loginBtn.click();
	}
	public void clickToohme() {
		gotohome.click();
	}
	
	
	
	
	
}
