package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ResetPasswordPage extends PageBase {

    public ResetPasswordPage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    @FindBy(id = "reset-mail")
    WebElement emailField;

   
    @FindBy(xpath = "//*[@id=\"forget_pass\"]/div[2]/button[2]/span")
    WebElement ResetButton;

    @FindBy(xpath = "//*[@id=\"forget_pass\"]/div[2]/button[1]")
    WebElement CancelButton;

 

    public void enterEmail(String email) {
        emailField.clear();
        emailField.sendKeys(email);
    }

    // Click reset button
    public void clickResetButton() {
        resetButton.click();
    }

    // Click cancel button
    public void clickCancelButton() {
        cancelButton.click();
    }

    // Check if email failed message is displayed
    public boolean isEmailFailedMessageDisplayed() {
        return emailFailedMessage.isDisplayed();
    }
}
