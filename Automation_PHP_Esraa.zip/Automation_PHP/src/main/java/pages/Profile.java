package pages;

import java.time.Duration;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ProfilePage extends PageBase {

    public ProfilePage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    @FindBy(id = "First Name")
    WebElement firstNameField;

    @FindBy(id = "Last Name")
    WebElement lastNameField;

    @FindBy(id = "Email")
    WebElement emailField;

    @FindBy(id = "Password")
    WebElement passwordField;

    @FindBy(id = "Phone")
    WebElement phoneField;

    @FindBy(id = "state")
    WebElement stateField;

    @FindBy(id = "City")
    WebElement cityField;

    @FindBy(id = "Address")
    WebElement address1Field;

    @FindBy(id = "address2")
    WebElement address2Field;

    @FindBy(id = "country")
    WebElement countryDropdown;

    @FindBy(className = "btn-bix mt-4")
    WebElement saveButton;


    public void enterFirstName(String firstName) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOf(firstNameField)).clear();
        firstNameField.sendKeys(firstName);
    }

    public void enterLastName(String lastName) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOf(lastNameField)).clear();
        lastNameField.sendKeys(lastName);
    }

    public void enterEmail(String email) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOf(emailField)).clear();
        emailField.sendKeys(email);
    }

    public void enterPassword(String password) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOf(passwordField)).clear();
        passwordField.sendKeys(password);
    }

    public void enterPhone(String phone) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOf(phoneField)).clear();
        phoneField.sendKeys(phone);
    }

    public void enterState(String state) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOf(stateField)).clear();
        stateField.sendKeys(state);
    }

    public void enterCity(String city) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOf(cityField)).clear();
        cityField.sendKeys(city);
    }

    public void enterAddress1(String address1) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOf(address1Field)).clear();
        address1Field.sendKeys(address1);
    }

    public void enterAddress2(String address2) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOf(address2Field)).clear();
        address2Field.sendKeys(address2);
    }

    public void selectCountry(String country) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOf(countryDropdown));
        Select countrySelect = new Select(countryDropdown);
        countrySelect.selectByVisibleText(country);
    }

    public void clickSave() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.elementToBeClickable(saveButton)).click();
    }

    public void fillProfile(String firstName, String lastName, String email, String password, String phone, 
                            String state, String city, String address1, String address2, String country) {
        enterFirstName(firstName);
        enterLastName(lastName);
        enterEmail(email);
        enterPassword(password);
        enterPhone(phone);
        enterState(state);
        enterCity(city);
        enterAddress1(address1);
        enterAddress2(address2);
        selectCountry(country);
    }

    public void saveProfile(String firstName, String lastName, String email, String password, String phone, 
                            String state, String city, String address1, String address2, String country) {
        fillProfile(firstName, lastName, email, password, phone, state, city, address1, address2, country);
        clickSave();
    }

    public boolean isProfileSaved() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        try {
            WebElement successMessage = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("success-message")));
            return successMessage.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }
}
