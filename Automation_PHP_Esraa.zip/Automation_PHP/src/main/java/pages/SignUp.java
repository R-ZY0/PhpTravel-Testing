package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SignupPage extends PageBase {

    public SignupPage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

 //ok
    @FindBy(id = "firstname") 
    WebElement firstName;
    //ok
    @FindBy(id = "last_name") 
    WebElement lastName;
   //ok 

@FindBy(xpath = "//*[@id=\"signup\"]/div/div/div/div[3]/div[1]/div/div/button")
WebElement countryDropdownButton;

@FindBy(xpath = "//*[@id=\"bs-select-1-1\"]")
List<WebElement> countryOptions;

public void selectCountry(String countryName) {
    countryDropdownButton.click();

    for (WebElement option : countryOptions) {
        if (option.getText().equals(countryName)) {
            option.click();
            break;
        }
    }
}

    //ok
    @FindBy(id = "phone") 
    WebElement phone;
    //ok
    @FindBy(id = "user_email") 
    WebElement email;
    //ok
    @FindBy(id = "password") 
    WebElement password;
    //ok
    @FindBy(xpath = "//*[@id=\"label\"]")
    WebElement captchaCheckbox;

    public void clickCaptchaCheckbox() {
        if (!captchaCheckbox.isSelected()) {
            captchaCheckbox.click();  
        }
    }
    //ok
    
    @FindBy(xpath = "//*[@id=\"signup\"]/div/div/div/div[7]/div/div/div[1]") 
    WebElement signupButton;


    public void fillSignupForm(String fname, String lname, String mobile, String mail, String pass) {
        firstName.sendKeys(fname);
        lastName.sendKeys(lname);
        phone.sendKeys(mobile);
        email.sendKeys(mail);
        password.sendKeys(pass);
    }

    public void clickSignup() {
        signupButton.click();
    }

    public void signup(String fname, String lname, String mobile, String mail, String pass) {
        fillSignupForm(fname, lname, mobile, mail, pass);
        clickSignup();
    }
}
