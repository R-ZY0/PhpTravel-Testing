package pages;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ToursPage extends PageBase {

    public ToursPage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    @FindBy(css = "//*[@id=\"fadein\"]/span/span/span[1]/input")  
    List<WebElement> cityOptions;

    @FindBy(id = "date")
    WebElement dateInput;
  

    @FindBy(id = "tours_adults")  
    WebElement adultsInput;

   
    @FindBy(id = "tours_child")  
    WebElement childrenInput;

    @FindBy(id = "search-button")
    WebElement searchButton;

    public void selectCity(String cityName) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfAllElements(cityOptions));

        for (WebElement city : cityOptions) {
            if (city.getText().trim().equalsIgnoreCase(cityName)) {
                city.click();
                break;
            }
        }
    }

    public void selectDate(String date) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOf(dateInput));
        dateInput.clear();
        dateInput.sendKeys(date);
    }

    public void setAdultTravellers(int adults) {
        if (adults <= 12 && adults >= 0) {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            wait.until(ExpectedConditions.visibilityOf(adultsInput));
            adultsInput.clear();
            adultsInput.sendKeys(String.valueOf(adults));
        } else {
            throw new IllegalArgumentException("Number of adults must be between 0 and 12.");
        }
    }

    // Set number of child travelers (max 12)
    public void setChildTravellers(int children) {
        if (children <= 12 && children >= 0) {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            wait.until(ExpectedConditions.visibilityOf(childrenInput));
            childrenInput.clear();
            childrenInput.sendKeys(String.valueOf(children));
        } else {
            throw new IllegalArgumentException("Number of children must be between 0 and 12.");
        }
    }

    public void clickSearch() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.elementToBeClickable(searchButton)).click();
    }

    public void searchForTour(String city, String date, int adults, int children) {
        selectCity(city);
        selectDate(date);
        setAdultTravellers(adults);
        setChildTravellers(children);
        clickSearch();
    }
}
