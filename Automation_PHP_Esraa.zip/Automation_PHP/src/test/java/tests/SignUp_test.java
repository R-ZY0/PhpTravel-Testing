package tests;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.By;
import java.time.Duration;
import pages.SignupPage;

public class SignupTest extends TestBase {
    SignupPage signupPage;

    @BeforeMethod
    public void initPageObjects() {
        signupPage = new SignupPage(driver);
    }

    @Test(priority = 1)
    public void testSignupWithValidData() {
        driver.get("https://app.phptravels.com/signup");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("firstname")));

        signupPage.fillSignupForm("Esraa", "Ibrahim", "01012345678", "esraa1234@test.com", "Esraa@1234");

        signupPage.selectCountry("Egypt");

        try {
            signupPage.clickCaptchaCheckbox();
        } catch (Exception e) {
            System.out.println("Captcha cannot be auto-clicked — skipping.");
        }

        signupPage.clickSignup();

        wait.until(ExpectedConditions.urlContains("account/dashboard"));

        String currentUrl = driver.getCurrentUrl();
        Assert.assertTrue(currentUrl.contains("account/dashboard"), "Signup did not navigate to dashboard!");

    }
}
