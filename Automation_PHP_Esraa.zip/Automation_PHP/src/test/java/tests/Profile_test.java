package tests;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.LoginPage;
import pages.ProfilePage;

public class Profile_HappyScenario extends TestBase {

    LoginPage loginPage;
    ProfilePage profilePage;

    @BeforeMethod
    public void initPages() {
        loginPage = new LoginPage(driver);
        profilePage = new ProfilePage(driver);
    }

    @Test(priority = 2)
    public void testUpdateProfileSuccessfully() {
        // login
        loginPage.userCanLogin("admin@example.com", "admin123");

        // save profile
        profilePage.saveProfile(
            "Esraa", "Ali", "esraa@phptests.com", "Pass1234",
            "0111111111", "Cairo", "Nasr City", "Street 123",
            "Near the Mall", "Egypt"
        );

        Assert.assertTrue(profilePage.isProfileSaved(), "Profile was not saved successfully.");
    }
}
