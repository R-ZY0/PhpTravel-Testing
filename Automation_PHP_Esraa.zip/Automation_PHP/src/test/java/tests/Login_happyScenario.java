package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.time.Duration;


import pages.Cars_search;
import pages.HomePage;
import pages.LoginPage;

public class Login_happyScenario extends TestBase{
	LoginPage loginObject = new LoginPage(driver);
	
	@Test(priority = 1)
	public void testLogin_CorrectUsernameAndPassword() {
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	    // Wait for login page message
	    wait.until(ExpectedConditions.visibilityOf(loginObject.loginMessage));
	    Assert.assertEquals("Login", loginObject.loginMessage.getText());

	    loginObject.userCanLogin("user@phptravels.com", "demouser");

	    // Wait for success message after login
	    wait.until(ExpectedConditions.visibilityOf(loginObject.successMassege));
	    Assert.assertEquals("Wallet Balance", loginObject.successMassege.getText());

	    loginObject.clickToohme();

	    // Wait for homepage message
	    wait.until(ExpectedConditions.visibilityOf(loginObject.home));
	    Assert.assertEquals("Your Trip Starts Here!", loginObject.home.getText());
	}

	 
}