package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import pages.ToursPage;

public class ToursPageTest {

    private WebDriver driver;
    private ToursPage toursPage;

    @BeforeClass
    public void setup() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.phptravels.net/#"); 
        toursPage = new ToursPage(driver);
    }

    @AfterClass
    public void teardown() {
        if (driver != null) {
            driver.quit();
        }
    }

    @Test
    public void testSearchTour() {
        String city = "Cairo";  
        String date = "2025-06-15";  
        int adults = 2;
        int children = 1;

        toursPage.searchForTour(city, date, adults, children);

        String currentUrl = driver.getCurrentUrl();
        Assert.assertTrue(currentUrl.contains("search_results"), "URL does not contain 'search_results'. Search failed.");
    }

    @Test(expectedExceptions = IllegalArgumentException.class)
    public void testSetInvalidNumberOfAdults() {
        toursPage.setAdultTravellers(15); 
    }

    // Test case for validating the number of children
    @Test(expectedExceptions = IllegalArgumentException.class)
    public void testSetInvalidNumberOfChildren() {
        toursPage.setChildTravellers(15); 
    }
}
