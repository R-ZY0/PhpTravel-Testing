package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import data.DataTest;
import data.LoadLoginProperties;

import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.time.Duration;

import pages.ResetPassword;
import pages.Cars_search_happey;

package tests;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.ResetPasswordPage;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.time.Duration;

public class ResetPasswordTest extends TestBase {

    ResetPasswordPage resetPasswordPage;

    @BeforeMethod
    public void setUpPage() {
        resetPasswordPage = new ResetPasswordPage(driver);
        driver.get("https://app.phptravels.com/user-forget-password"); 
    }

    @Test(priority = 1)
    public void testResetPassword_WithValidEmail() {
        resetPasswordPage.enterEmail("test@example.com");
        resetPasswordPage.clickResetButton();


        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));


        System.out.println("Reset request sent with valid email.");
    }

    @Test(priority = 2)
    public void testResetPassword_WithInvalidEmail() {
        resetPasswordPage.enterEmail("invalid-email");
        resetPasswordPage.clickResetButton();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
        wait.until(ExpectedConditions.visibilityOf(resetPasswordPage.emailFailedMessage));

        Assert.assertTrue(resetPasswordPage.isEmailFailedMessageDisplayed(), "Expected error message for invalid email.");
    }

    @Test(priority = 3)
    public void testCancelButton() {
        resetPasswordPage.clickCancelButton();
:
        Assert.assertTrue(driver.getCurrentUrl().contains("login") || driver.getTitle().contains("Login"));
    }
}

